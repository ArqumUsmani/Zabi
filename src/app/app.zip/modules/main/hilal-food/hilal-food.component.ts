import { Component } from '@angular/core';

@Component({
  selector: 'app-hilal-food',
  templateUrl: './hilal-food.component.html',
  styleUrls: ['./hilal-food.component.scss']
})
export class HilalFoodComponent {

}
