import { Component } from '@angular/core';

@Component({
  selector: 'app-prayer-spaces',
  templateUrl: './prayer-spaces.component.html',
  styleUrls: ['./prayer-spaces.component.scss']
})
export class PrayerSpacesComponent {

}
