import { Component } from '@angular/core';

@Component({
  selector: 'app-pickup-and-delivery',
  templateUrl: './pickup-and-delivery.component.html',
  styleUrls: ['./pickup-and-delivery.component.scss']
})
export class PickupAndDeliveryComponent {

}
